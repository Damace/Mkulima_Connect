class ImageConstant {
  static String imgTelevision = 'assets/images/img_television.svg';

  static String imgCloseWhiteA7001 = 'assets/images/img_close_white_a700_1.svg';

  static String imgShape50x502 = 'assets/images/img_shape_50x50_2.png';

  static String imgText4 = 'assets/images/img_text_4.png';

  static String imgVolume11x20 = 'assets/images/img_volume_11x20.svg';

  static String imgShape60x606 = 'assets/images/img_shape_60x60_6.png';

  static String imgLocation9x9 = 'assets/images/img_location_9x9.svg';

  static String imgShape100x1007 = 'assets/images/img_shape_100x100_7.png';

  static String imgShape70x701 = 'assets/images/img_shape_70x70_1.png';

  static String imgRewind22x22 = 'assets/images/img_rewind_22x22.svg';

  static String imgCilbathroom = 'assets/images/img_cilbathroom.png';

  static String imgMap812x375 = 'assets/images/img_map_812x375.png';

  static String imgShape50x507 = 'assets/images/img_shape_50x50_7.png';

  static String imgText13 = 'assets/images/img_text_13.png';

  static String img360view = 'assets/images/img_360view.png';

  static String imgShape104x1261 = 'assets/images/img_shape_104x126_1.png';

  static String imgShape104x1262 = 'assets/images/img_shape_104x126_2.png';

  static String imgShape160x1443 = 'assets/images/img_shape_160x144_3.png';

  static String imgVector29x29 = 'assets/images/img_vector_29x29.png';

  static String imgTicket53x53 = 'assets/images/img_ticket_53x53.svg';

  static String imgShape100x1004 = 'assets/images/img_shape_100x100_4.png';

  static String imgShape160x14415 = 'assets/images/img_shape_160x144_15.png';

  static String imgVector = 'assets/images/img_vector.png';

  static String imgShape140x1685 = 'assets/images/img_shape_140x168_5.png';

  static String imgMenu1 = 'assets/images/img_menu_1.svg';

  static String imgAlarm20x20 = 'assets/images/img_alarm_20x20.svg';

  static String imgFavoriteBlueGray80001 =
      'assets/images/img_favorite_blue_gray_800_01.svg';

  static String imgShape30x302 = 'assets/images/img_shape_30x30_2.png';

  static String imgUser20x20 = 'assets/images/img_user_20x20.svg';

  static String imgShape160x14420 = 'assets/images/img_shape_160x144_20.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgMail20x20 = 'assets/images/img_mail_20x20.svg';

  static String imgMenu12x12 = 'assets/images/img_menu_12x12.svg';

  static String imgGroupRedA200 = 'assets/images/img_group_red_a200.svg';

  static String imgShape19 = 'assets/images/img_shape_19.png';

  static String imgText3 = 'assets/images/img_text_3.png';

  static String imgShape160x14414 = 'assets/images/img_shape_160x144_14.png';

  static String imgShape50x5011 = 'assets/images/img_shape_50x50_11.png';

  static String imgIconoirnavarrowdown =
      'assets/images/img_iconoirnavarrowdown.png';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgShape160x14418 = 'assets/images/img_shape_160x144_18.png';

  static String imgShape100x1102 = 'assets/images/img_shape_100x110_2.png';

  static String imgShape161x1592 = 'assets/images/img_shape_161x159_2.png';

  static String imgGroup6503 = 'assets/images/img_group6503.png';

  static String imgMap300x327 = 'assets/images/img_map_300x327.png';

  static String imgBackgroundillustration520x3751 =
      'assets/images/img_backgroundillustration_520x375_1.png';

  static String imgShape50x501 = 'assets/images/img_shape_50x50_1.png';

  static String imgShape140x1263 = 'assets/images/img_shape_140x126_3.png';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgText14 = 'assets/images/img_text_14.png';

  static String imgText1 = 'assets/images/img_text_1.png';

  static String imgText6 = 'assets/images/img_text_6.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgShape161x1591 = 'assets/images/img_shape_161x159_1.png';

  static String imgShape60x604 = 'assets/images/img_shape_60x60_4.png';

  static String imgShape40x404 = 'assets/images/img_shape_40x40_4.png';

  static String imgIconwallet = 'assets/images/img_iconwallet.svg';

  static String imgShape160x1444 = 'assets/images/img_shape_160x144_4.png';

  static String img = 'assets/images/img_.png';

  static String imgClock = 'assets/images/img_clock.svg';

  static String img9ce8cff206464d90abe590abdd2875e0 =
      'assets/images/img_9ce8cff206464d90abe590abdd2875e0.svg';

  static String imgShape50x504 = 'assets/images/img_shape_50x50_4.png';

  static String imgShape161x1594 = 'assets/images/img_shape_161x159_4.png';

  static String imgFacebook = 'assets/images/img_facebook.svg';

  static String imgVolumeBlueGray80001 =
      'assets/images/img_volume_blue_gray_800_01.svg';

  static String imgUpload50x50 = 'assets/images/img_upload_50x50.svg';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgLocation50x50 = 'assets/images/img_location_50x50.svg';

  static String imgReply = 'assets/images/img_reply.svg';

  static String imgUserBlueGray80001 =
      'assets/images/img_user_blue_gray_800_01.svg';

  static String imgShape100x1006 = 'assets/images/img_shape_100x100_6.png';

  static String imgArrowdownIndigo200 =
      'assets/images/img_arrowdown_indigo_200.svg';

  static String imgArrowdown10x10 = 'assets/images/img_arrowdown_10x10.svg';

  static String imgShape160x1448 = 'assets/images/img_shape_160x144_8.png';

  static String imgShape161x1593 = 'assets/images/img_shape_161x159_3.png';

  static String imgShape = 'assets/images/img_shape.svg';

  static String imgShape50x509 = 'assets/images/img_shape_50x50_9.png';

  static String imgVector7 = 'assets/images/img_vector7.svg';

  static String imgSearchBlack900 = 'assets/images/img_search_black_900.svg';

  static String imgShape160x1447 = 'assets/images/img_shape_160x144_7.png';

  static String imgVolume50x50 = 'assets/images/img_volume_50x50.svg';

  static String imgShape174x1445 = 'assets/images/img_shape_174x144_5.png';

  static String imgClose12x12 = 'assets/images/img_close_12x12.svg';

  static String imgLocation1 = 'assets/images/img_location_1.svg';

  static String imgAe45615de12342ab99f19311ea988aa7 =
      'assets/images/img_ae45615de12342ab99f19311ea988aa7.svg';

  static String imgCheckmark10x10 = 'assets/images/img_checkmark_10x10.svg';

  static String imgShape50x601 = 'assets/images/img_shape_50x60_1.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgBackgroundillustration520x3753 =
      'assets/images/img_backgroundillustration_520x375_3.png';

  static String imgText15 = 'assets/images/img_text_15.png';

  static String imgButtoncategory1 = 'assets/images/img_buttoncategory_1.png';

  static String imgIcbaselinewaterdrop =
      'assets/images/img_icbaselinewaterdrop.png';

  static String imgCameraBlueGray600 =
      'assets/images/img_camera_blue_gray_600.svg';

  static String imgText9 = 'assets/images/img_text_9.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgBackgroundillustration520x3752 =
      'assets/images/img_backgroundillustration_520x375_2.png';

  static String imgShape174x1446 = 'assets/images/img_shape_174x144_6.png';

  static String imgRectangle2 = 'assets/images/img_rectangle2.png';

  static String imgButtoncategory2 = 'assets/images/img_buttoncategory_2.png';

  static String imgButtoncategory = 'assets/images/img_buttoncategory.png';

  static String imgLocationDeepOrangeA20050x50 =
      'assets/images/img_location_deep_orange_a200_50x50.svg';

  static String img2 = 'assets/images/img__2.png';

  static String imgDashboard = 'assets/images/img_dashboard.svg';

  static String imgShape100x1005 = 'assets/images/img_shape_100x100_5.png';

  static String imgShape160x14422 = 'assets/images/img_shape_160x144_22.png';

  static String imgVector1 = 'assets/images/img_vector_1.png';

  static String imgText = 'assets/images/img_text.png';

  static String imgLocation5 = 'assets/images/img_location_5.svg';

  static String imgShape60x601 = 'assets/images/img_shape_60x60_1.png';

  static String imgLocation9 = 'assets/images/img_location_9.svg';

  static String imgText18x16 = 'assets/images/img_text_18x16.png';

  static String imgLocation7 = 'assets/images/img_location_7.svg';

  static String imgMap1 = 'assets/images/img_map_1.png';

  static String imgLocation3 = 'assets/images/img_location_3.svg';

  static String imgLocation51x34 = 'assets/images/img_location_51x34.svg';

  static String imgText11 = 'assets/images/img_text_11.png';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgVectorIndigoA400 =
      'assets/images/img_vector_indigo_a400.svg';

  static String imgTrashBlueGray80001 =
      'assets/images/img_trash_blue_gray_800_01.svg';

  static String imgShape30x303 = 'assets/images/img_shape_30x30_3.png';

  static String imgShape30x304 = 'assets/images/img_shape_30x30_4.png';

  static String imgMap200x327 = 'assets/images/img_map_200x327.png';

  static String imgSend = 'assets/images/img_send.svg';

  static String imgShape161x1596 = 'assets/images/img_shape_161x159_6.png';

  static String imgMenu10x10 = 'assets/images/img_menu_10x10.svg';

  static String imgShape520x375 = 'assets/images/img_shape_520x375.png';

  static String imgShape24 = 'assets/images/img_shape_24.png';

  static String imgShape60x603 = 'assets/images/img_shape_60x60_3.png';

  static String imgShape60x605 = 'assets/images/img_shape_60x60_5.png';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgShape50x503 = 'assets/images/img_shape_50x50_3.png';

  static String imgText7 = 'assets/images/img_text_7.png';

  static String imgComputer20x20 = 'assets/images/img_computer_20x20.svg';

  static String imgShape100x1001 = 'assets/images/img_shape_100x100_1.png';

  static String imgShape140x1682 = 'assets/images/img_shape_140x168_2.png';

  static String imgShape140x1262 = 'assets/images/img_shape_140x126_2.png';

  static String imgLocation8 = 'assets/images/img_location_8.svg';

  static String imgIconhouseactive = 'assets/images/img_iconhouseactive.svg';

  static String imgCheckmark16x16 = 'assets/images/img_checkmark_16x16.svg';

  static String imgShape40x401 = 'assets/images/img_shape_40x40_1.png';

  static String imgShape70x705 = 'assets/images/img_shape_70x70_5.png';

  static String imgShape160x14410 = 'assets/images/img_shape_160x144_10.png';

  static String img18x15 = 'assets/images/img__18x15.png';

  static String imgLightbulbOrange300 =
      'assets/images/img_lightbulb_orange_300.svg';

  static String imgShape174x1444 = 'assets/images/img_shape_174x144_4.png';

  static String imgShape160x14419 = 'assets/images/img_shape_160x144_19.png';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgSubtractWhiteA700 =
      'assets/images/img_subtract_white_a700.png';

  static String imgSearch20x20 = 'assets/images/img_search_20x20.svg';

  static String imgRewind = 'assets/images/img_rewind.svg';

  static String imgPlus10x10 = 'assets/images/img_plus_10x10.svg';

  static String imgShape36x74 = 'assets/images/img_shape_36x74.png';

  static String imgButtoncategory25x25 =
      'assets/images/img_buttoncategory_25x25.png';

  static String imgUpload = 'assets/images/img_upload.svg';

  static String imgShape210x1101 = 'assets/images/img_shape_210x110_1.png';

  static String imgRectangle3 = 'assets/images/img_rectangle3.png';

  static String imgReviewsgallery = 'assets/images/img_reviewsgallery.png';

  static String imgText18x15 = 'assets/images/img_text_18x15.png';

  static String imgShape70x703 = 'assets/images/img_shape_70x70_3.png';

  static String imgShape161x1597 = 'assets/images/img_shape_161x159_7.png';

  static String imgGroup6524 = 'assets/images/img_group6524.png';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgShape50x506 = 'assets/images/img_shape_50x50_6.png';

  static String imgMap235x327 = 'assets/images/img_map_235x327.png';

  static String imgIconmicmuteBlueGray80001 =
      'assets/images/img_iconmicmute_blue_gray_800_01.svg';

  static String imgShape160x1442 = 'assets/images/img_shape_160x144_2.png';

  static String imgUser1 = 'assets/images/img_user_1.svg';

  static String imgUserIndigoA400 = 'assets/images/img_user_indigo_a400.svg';

  static String imgShape53x531 = 'assets/images/img_shape_53x53_1.png';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgAlarm = 'assets/images/img_alarm.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgShape130x130 = 'assets/images/img_shape_130x130.png';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imgShape100x1003 = 'assets/images/img_shape_100x100_3.png';

  static String imgMail1 = 'assets/images/img_mail_1.svg';

  static String imgShape40x403 = 'assets/images/img_shape_40x40_3.png';

  static String imgShape160x1449 = 'assets/images/img_shape_160x144_9.png';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgShape161x1595 = 'assets/images/img_shape_161x159_5.png';

  static String imgSettings50x50 = 'assets/images/img_settings_50x50.svg';

  static String imgText5 = 'assets/images/img_text_5.png';

  static String imgShape40x402 = 'assets/images/img_shape_40x40_2.png';

  static String imgQuestionWhiteA700 =
      'assets/images/img_question_white_a700.svg';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgShape160x14421 = 'assets/images/img_shape_160x144_21.png';

  static String imgLocation4 = 'assets/images/img_location_4.svg';

  static String imgShape160x1445 = 'assets/images/img_shape_160x144_5.png';

  static String imgLocation43x34 = 'assets/images/img_location_43x34.svg';

  static String imgC6f6d1d0a80c478fac3dcfbb08744752 =
      'assets/images/img_c6f6d1d0a80c478fac3dcfbb08744752.svg';

  static String imgShape174x1443 = 'assets/images/img_shape_174x144_3.png';

  static String imgSubtract145x207 = 'assets/images/img_subtract_145x207.png';

  static String imgLocationDeepOrangeA200 =
      'assets/images/img_location_deep_orange_a200.svg';

  static String imgShape70x704 = 'assets/images/img_shape_70x70_4.png';

  static String imgShape518x375 = 'assets/images/img_shape_518x375.png';

  static String imgShape50x602 = 'assets/images/img_shape_50x60_2.png';

  static String imgStar9x9 = 'assets/images/img_star_9x9.svg';

  static String imgLocation2 = 'assets/images/img_location_2.svg';

  static String imgReply20x20 = 'assets/images/img_reply_20x20.svg';

  static String imgShape104x128 = 'assets/images/img_shape_104x128.png';

  static String imgUser25x25 = 'assets/images/img_user_25x25.svg';

  static String imgMap = 'assets/images/img_map.png';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgVectorGray100 = 'assets/images/img_vector_gray_100.svg';

  static String imgSubtract = 'assets/images/img_subtract.svg';

  static String imgShape160x1441 = 'assets/images/img_shape_160x144_1.png';

  static String imgShape160x14416 = 'assets/images/img_shape_160x144_16.png';

  static String imgShape50x5010 = 'assets/images/img_shape_50x50_10.png';

  static String imgShape54 = 'assets/images/img_shape_54.png';

  static String imgText10 = 'assets/images/img_text_10.png';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgTelevision12x12 = 'assets/images/img_television_12x12.svg';

  static String imgShape70x702 = 'assets/images/img_shape_70x70_2.png';

  static String imgText16 = 'assets/images/img_text_16.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgShape60x602 = 'assets/images/img_shape_60x60_2.png';

  static String imgSplashscreen = 'assets/images/img_splashscreen.png';

  static String imgFavorite34x25 = 'assets/images/img_favorite_34x25.svg';

  static String imgMapdetail = 'assets/images/img_mapdetail.png';

  static String imgLocation6 = 'assets/images/img_location_6.svg';

  static String imgShape104x1281 = 'assets/images/img_shape_104x128_1.png';

  static String imgShape160x1446 = 'assets/images/img_shape_160x144_6.png';

  static String imgShape320x2352 = 'assets/images/img_shape_320x235_2.png';

  static String imgText2 = 'assets/images/img_text_2.png';

  static String imgUser42x40 = 'assets/images/img_user_42x40.svg';

  static String imgFavoriteWhiteA700 =
      'assets/images/img_favorite_white_a700.svg';

  static String imgMdibedempty = 'assets/images/img_mdibedempty.png';

  static String imgClock9x9 = 'assets/images/img_clock_9x9.svg';

  static String imgShape100x1002 = 'assets/images/img_shape_100x100_2.png';

  static String imgLocation20x20 = 'assets/images/img_location_20x20.svg';

  static String imgProgressbargradient =
      'assets/images/img_progressbargradient.png';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgComputer = 'assets/images/img_computer.svg';

  static String imgLocationRedA200 = 'assets/images/img_location_red_a200.svg';

  static String imgText8 = 'assets/images/img_text_8.png';

  static String imgShape100x1008 = 'assets/images/img_shape_100x100_8.png';

  static String imgShape210x1102 = 'assets/images/img_shape_210x110_2.png';

  static String imgShape160x14412 = 'assets/images/img_shape_160x144_12.png';

  static String imgShape160x14411 = 'assets/images/img_shape_160x144_11.png';

  static String imgShape140x1261 = 'assets/images/img_shape_140x126_1.png';

  static String imgStar1 = 'assets/images/img_star_1.svg';

  static String imgShape140x1681 = 'assets/images/img_shape_140x168_1.png';

  static String imgText12 = 'assets/images/img_text_12.png';

  static String imgShape320x2351 = 'assets/images/img_shape_320x235_1.png';

  static String imgMaximize = 'assets/images/img_maximize.svg';

  static String imgShape160x14413 = 'assets/images/img_shape_160x144_13.png';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgText17 = 'assets/images/img_text_17.png';

  static String imgShape140x1683 = 'assets/images/img_shape_140x168_3.png';

  static String imgShape174x1441 = 'assets/images/img_shape_174x144_1.png';

  static String imgBackground = 'assets/images/img_background.png';

  static String imgShape140x1684 = 'assets/images/img_shape_140x168_4.png';

  static String img1 = 'assets/images/img__1.png';

  static String imgShape100x1101 = 'assets/images/img_shape_100x110_1.png';

  static String imgCalendar9x9 = 'assets/images/img_calendar_9x9.svg';

  static String imgBackgroundillustration416x3551 =
      'assets/images/img_backgroundillustration_416x355_1.png';

  static String imgMenuBlueGray80001 =
      'assets/images/img_menu_blue_gray_800_01.svg';

  static String imgShape174x1442 = 'assets/images/img_shape_174x144_2.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
