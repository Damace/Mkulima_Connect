import 'package:mkulima_connect/core/app_export.dart';

class ApiClient extends GetConnect {}
