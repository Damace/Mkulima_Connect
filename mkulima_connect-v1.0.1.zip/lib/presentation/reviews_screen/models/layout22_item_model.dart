import 'package:get/get.dart';class Layout22ItemModel {Rx<String> nameTxt = Rx("Kurt Mullins");

Rx<String>? id = Rx("");

 }
