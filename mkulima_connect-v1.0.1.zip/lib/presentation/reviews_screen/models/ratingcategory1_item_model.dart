import 'package:get/get.dart';class Ratingcategory1ItemModel {Rx<String> textOneTxt = Rx("All");

Rx<String>? id = Rx("");

 }
