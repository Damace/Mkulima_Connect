import 'package:get/get.dart';import 'ratingcategory1_item_model.dart';import 'layout22_item_model.dart';class ReviewsModel {Rx<List<Ratingcategory1ItemModel>> ratingcategory1ItemList = Rx(List.generate(5,(index) => Ratingcategory1ItemModel()));

Rx<List<Layout22ItemModel>> layout22ItemList = Rx(List.generate(3,(index) => Layout22ItemModel()));

 }
