import 'package:get/get.dart';class RatingcategoryItemModel {Rx<String> textOneTxt = Rx("All");

Rx<String>? id = Rx("");

 }
