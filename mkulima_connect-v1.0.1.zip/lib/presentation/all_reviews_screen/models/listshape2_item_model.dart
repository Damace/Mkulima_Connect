import 'package:get/get.dart';class Listshape2ItemModel {Rx<String>? id = Rx("");

 }
