class SummarySuccessModel { }
