import 'package:get/get.dart';class ChipviewItemModel {Rx<String> buttonFilterTxt = Rx("House");

Rx<bool> isSelected = Rx(false);

 }
