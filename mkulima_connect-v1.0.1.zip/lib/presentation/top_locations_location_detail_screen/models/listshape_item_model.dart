import 'package:get/get.dart';class ListshapeItemModel {Rx<String>? id = Rx("");

 }
