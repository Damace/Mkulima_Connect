class DeleteConfirmationModel { }
