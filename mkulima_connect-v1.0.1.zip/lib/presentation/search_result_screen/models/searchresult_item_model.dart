import 'package:get/get.dart';class SearchresultItemModel {Rx<String> priceTxt = Rx(" 235");

Rx<String> typeTxt = Rx("Bungalow House");

Rx<String> ratingTxt = Rx("4.7");

Rx<String> countryTxt = Rx("Jakarta, Indonesia");

Rx<String>? id = Rx("");

 }
