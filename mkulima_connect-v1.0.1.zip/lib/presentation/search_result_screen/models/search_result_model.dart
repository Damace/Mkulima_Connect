import 'package:get/get.dart';import 'searchresult_item_model.dart';class SearchResultModel {Rx<List<SearchresultItemModel>> searchresultItemList = Rx(List.generate(6,(index) => SearchresultItemModel()));

 }
