class EmptySearchModel { }
