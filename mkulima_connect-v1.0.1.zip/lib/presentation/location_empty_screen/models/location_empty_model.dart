class LocationEmptyModel { }
