import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/location_empty_screen/models/location_empty_model.dart';class LocationEmptyController extends GetxController {Rx<LocationEmptyModel> locationEmptyModelObj = LocationEmptyModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
