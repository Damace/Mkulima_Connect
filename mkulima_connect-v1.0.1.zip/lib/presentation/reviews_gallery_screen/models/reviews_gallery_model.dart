class ReviewsGalleryModel { }
