import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/reviews_gallery_screen/models/reviews_gallery_model.dart';class ReviewsGalleryController extends GetxController {Rx<ReviewsGalleryModel> reviewsGalleryModelObj = ReviewsGalleryModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
