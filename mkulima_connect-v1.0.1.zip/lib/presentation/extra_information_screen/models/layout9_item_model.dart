import 'package:get/get.dart';class Layout9ItemModel {Rx<String> buttonCategorySixTxt = Rx("Parking Lot");

Rx<bool> isSelected = Rx(false);

 }
