import 'package:get/get.dart';class Layout5ItemModel {Rx<String> buttonCategoryTxt = Rx("Monthly");

Rx<bool> isSelected = Rx(false);

 }
