import 'package:get/get.dart';class ListtypeItemModel {Rx<String> typeTxt = Rx("Bedroom");

Rx<String> sizeTxt = Rx("3");

Rx<String>? id = Rx("");

 }
