import 'package:get/get.dart';class Layout7ItemModel {Rx<String> buttonCategoryTwoTxt = Rx("< 4");

Rx<bool> isSelected = Rx(false);

 }
