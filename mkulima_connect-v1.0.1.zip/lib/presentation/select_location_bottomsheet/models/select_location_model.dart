class SelectLocationModel { }
