class LocationDistanceModel { }
