class LocationChooseLocationModel { }
