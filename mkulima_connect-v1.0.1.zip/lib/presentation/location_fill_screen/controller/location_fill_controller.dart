import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/location_fill_screen/models/location_fill_model.dart';class LocationFillController extends GetxController {Rx<LocationFillModel> locationFillModelObj = LocationFillModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
