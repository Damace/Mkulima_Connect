class LocationFillModel { }
