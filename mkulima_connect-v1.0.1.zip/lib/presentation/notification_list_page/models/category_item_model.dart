import 'package:get/get.dart';class CategoryItemModel {Rx<String> textOneTxt = Rx("All");

Rx<String>? id = Rx("");

 }
