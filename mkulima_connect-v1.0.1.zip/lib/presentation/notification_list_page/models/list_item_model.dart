import 'package:get/get.dart';class ListItemModel {Rx<String> senderTxt = Rx("Emmett Perry");

Rx<String> timeTxt = Rx("10 mins ago");

Rx<String>? id = Rx("");

 }
