import 'package:mkulima_connect/core/app_export.dart';
import 'package:mkulima_connect/presentation/edit_success_bottomsheet/models/edit_success_model.dart';

class EditSuccessController extends GetxController {
  Rx<EditSuccessModel> editSuccessModelObj = EditSuccessModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
