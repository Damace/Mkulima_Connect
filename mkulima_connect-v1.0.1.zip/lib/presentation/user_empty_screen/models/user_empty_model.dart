class UserEmptyModel { }
