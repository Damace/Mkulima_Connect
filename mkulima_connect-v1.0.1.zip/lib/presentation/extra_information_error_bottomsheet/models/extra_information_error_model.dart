class ExtraInformationErrorModel { }
