import 'package:mkulima_connect/core/app_export.dart';
import 'package:mkulima_connect/presentation/extra_information_error_bottomsheet/models/extra_information_error_model.dart';

class ExtraInformationErrorController extends GetxController {
  Rx<ExtraInformationErrorModel> extraInformationErrorModelObj =
      ExtraInformationErrorModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
