import 'package:get/get.dart';class Layout11ItemModel {Rx<String> textThreeTxt = Rx("4.9");

Rx<String>? id = Rx("");

 }
