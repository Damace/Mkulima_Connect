import 'package:get/get.dart';class Listshape1ItemModel {Rx<String>? id = Rx("");

 }
