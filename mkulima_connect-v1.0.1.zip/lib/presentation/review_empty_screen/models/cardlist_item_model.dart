import 'package:get/get.dart';class CardlistItemModel {Rx<String> accountnumberTxt = Rx("•••••••• 1222");

Rx<String>? id = Rx("");

 }
