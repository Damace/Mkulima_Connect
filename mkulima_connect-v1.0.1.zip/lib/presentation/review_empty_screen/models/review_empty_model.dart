import 'package:get/get.dart';import 'cardlist_item_model.dart';class ReviewEmptyModel {Rx<List<CardlistItemModel>> cardlistItemList = Rx(List.generate(3,(index) => CardlistItemModel()));

 }
