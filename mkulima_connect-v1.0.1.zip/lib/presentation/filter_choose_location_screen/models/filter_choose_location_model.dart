class FilterChooseLocationModel { }
