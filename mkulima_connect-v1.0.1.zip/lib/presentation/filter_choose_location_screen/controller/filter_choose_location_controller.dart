import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/filter_choose_location_screen/models/filter_choose_location_model.dart';class FilterChooseLocationController extends GetxController {Rx<FilterChooseLocationModel> filterChooseLocationModelObj = FilterChooseLocationModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
