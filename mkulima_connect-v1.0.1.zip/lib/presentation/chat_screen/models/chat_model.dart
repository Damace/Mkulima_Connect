class ChatModel { }
