import 'package:get/get.dart';class HorizontalItemModel {Rx<String> typeTxt = Rx("Villa");

Rx<String> nameTxt = Rx("Bali Beachview Villa");

Rx<String> languageTxt = Rx("4.2 ");

Rx<String> countryTxt = Rx("Bali, Indonesia");

Rx<String> priceTxt = Rx(" 420");

Rx<String>? id = Rx("");

 }
