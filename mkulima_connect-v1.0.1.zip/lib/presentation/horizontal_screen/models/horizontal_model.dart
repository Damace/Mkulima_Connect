import 'package:get/get.dart';import 'horizontal_item_model.dart';class HorizontalModel {Rx<List<HorizontalItemModel>> horizontalItemList = Rx(List.generate(3,(index) => HorizontalItemModel()));

 }
