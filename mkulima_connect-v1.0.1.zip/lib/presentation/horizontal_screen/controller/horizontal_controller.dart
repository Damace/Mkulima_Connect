import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/horizontal_screen/models/horizontal_model.dart';class HorizontalController extends GetxController {Rx<HorizontalModel> horizontalModelObj = HorizontalModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
