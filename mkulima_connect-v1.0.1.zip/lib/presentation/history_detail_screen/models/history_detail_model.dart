class HistoryDetailModel { }
