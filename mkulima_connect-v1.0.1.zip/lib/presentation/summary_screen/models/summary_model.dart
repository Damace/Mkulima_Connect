class SummaryModel { }
