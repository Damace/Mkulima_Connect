class RegisterFormEmptyModel { }
