import 'package:get/get.dart';class ListtextItemModel {Rx<String> textTxt = Rx("Halloween \nSale!");

Rx<String>? id = Rx("");

 }
