import 'package:get/get.dart';class Layout24ItemModel {Rx<String> nameTxt = Rx("Bali");

Rx<String>? id = Rx("");

 }
