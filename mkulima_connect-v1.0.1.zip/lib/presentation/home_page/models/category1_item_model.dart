import 'package:get/get.dart';class Category1ItemModel {Rx<String> textOneTxt = Rx("All");

Rx<String>? id = Rx("");

 }
