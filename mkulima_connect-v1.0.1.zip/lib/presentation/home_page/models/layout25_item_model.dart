import 'package:get/get.dart';class Layout25ItemModel {Rx<String> nameTxt = Rx("Amanda");

Rx<String>? id = Rx("");

 }
