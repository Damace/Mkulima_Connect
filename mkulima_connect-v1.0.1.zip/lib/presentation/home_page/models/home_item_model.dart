import 'package:get/get.dart';class HomeItemModel {Rx<String> priceTxt = Rx(" 220");

Rx<String> nameTxt = Rx("Wings Tower");

Rx<String> ratingTxt = Rx("4.9");

Rx<String>? id = Rx("");

 }
