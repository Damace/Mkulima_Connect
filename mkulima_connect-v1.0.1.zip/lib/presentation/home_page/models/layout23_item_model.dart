import 'package:get/get.dart';class Layout23ItemModel {Rx<String> textOneTxt = Rx("Apartment");

Rx<String> textThreeTxt = Rx("4.9");

Rx<String> priceTxt = Rx(" 290");

Rx<String>? id = Rx("");

 }
