class ExtraInformationSuccessModel { }
