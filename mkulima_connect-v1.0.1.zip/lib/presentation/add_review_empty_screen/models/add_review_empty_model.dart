class AddReviewEmptyModel { }
