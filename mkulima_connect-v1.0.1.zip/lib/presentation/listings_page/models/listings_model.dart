import 'package:get/get.dart';import 'listings_item_model.dart';class ListingsModel {Rx<List<ListingsItemModel>> listingsItemList = Rx(List.generate(4,(index) => ListingsItemModel()));

 }
