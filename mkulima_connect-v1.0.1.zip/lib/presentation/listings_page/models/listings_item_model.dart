import 'package:get/get.dart';class ListingsItemModel {Rx<String> priceTxt = Rx(" 370");

Rx<String> nameTxt = Rx("Fairview Apartment");

Rx<String> ratingTxt = Rx("4.9");

Rx<String>? id = Rx("");

 }
