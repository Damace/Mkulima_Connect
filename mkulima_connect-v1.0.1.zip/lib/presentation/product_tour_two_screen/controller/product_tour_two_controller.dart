import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/product_tour_two_screen/models/product_tour_two_model.dart';class ProductTourTwoController extends GetxController {Rx<ProductTourTwoModel> productTourTwoModelObj = ProductTourTwoModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
