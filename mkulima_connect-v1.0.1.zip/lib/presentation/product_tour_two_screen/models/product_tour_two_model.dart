class ProductTourTwoModel { }
