class FormEmptyModel { }
