import 'package:get/get.dart';import 'chipview2_item_model.dart';import 'chipviewone_item_model.dart';class FilterFullModel {Rx<List<Chipview2ItemModel>> chipview2ItemList = Rx(List.generate(2,(index) =>Chipview2ItemModel()));

Rx<List<ChipviewoneItemModel>> chipviewoneItemList = Rx(List.generate(7,(index) =>ChipviewoneItemModel()));

 }
