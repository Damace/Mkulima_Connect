import 'package:get/get.dart';class Chipview2ItemModel {Rx<String> buttonCategoryTxt = Rx("Rent");

Rx<bool> isSelected = Rx(false);

 }
