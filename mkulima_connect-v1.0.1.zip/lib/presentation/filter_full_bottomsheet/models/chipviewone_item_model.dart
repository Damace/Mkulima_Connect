import 'package:get/get.dart';class ChipviewoneItemModel {Rx<String> buttonCategoryTwoTxt = Rx("Home theatre");

Rx<bool> isSelected = Rx(false);

 }
