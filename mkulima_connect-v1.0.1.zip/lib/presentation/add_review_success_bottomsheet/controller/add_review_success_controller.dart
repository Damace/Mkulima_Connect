import 'package:mkulima_connect/core/app_export.dart';
import 'package:mkulima_connect/presentation/add_review_success_bottomsheet/models/add_review_success_model.dart';

class AddReviewSuccessController extends GetxController {
  Rx<AddReviewSuccessModel> addReviewSuccessModelObj =
      AddReviewSuccessModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
