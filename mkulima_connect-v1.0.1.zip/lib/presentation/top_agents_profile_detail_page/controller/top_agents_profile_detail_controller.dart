import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/top_agents_profile_detail_page/models/top_agents_profile_detail_model.dart';class TopAgentsProfileDetailController extends GetxController {TopAgentsProfileDetailController(this.topAgentsProfileDetailModelObj);

Rx<TopAgentsProfileDetailModel> topAgentsProfileDetailModelObj;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
