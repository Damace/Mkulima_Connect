import 'package:get/get.dart';import 'gridshape2_item_model.dart';class TopAgentsProfileDetailModel {Rx<List<Gridshape2ItemModel>> gridshape2ItemList = Rx(List.generate(4,(index) => Gridshape2ItemModel()));

 }
