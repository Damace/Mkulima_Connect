import 'package:get/get.dart';class Gridshape2ItemModel {Rx<String> priceTxt = Rx(" 320");

Rx<String> propertynameTxt = Rx("Brookvale Villa");

Rx<String>? id = Rx("");

 }
