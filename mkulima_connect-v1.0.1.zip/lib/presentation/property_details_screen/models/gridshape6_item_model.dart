import 'package:get/get.dart';class Gridshape6ItemModel {Rx<String> priceOneTxt = Rx(" 190");

Rx<String> languageTxt = Rx("Sky Dandelions ");

Rx<String> textTwoTxt = Rx("4.9");

Rx<String>? id = Rx("");

 }
