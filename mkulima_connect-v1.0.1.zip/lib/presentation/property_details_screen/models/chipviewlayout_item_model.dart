import 'package:get/get.dart';class ChipviewlayoutItemModel {Rx<String> layoutTxt = Rx("Rent");

Rx<bool> isSelected = Rx(false);

 }
