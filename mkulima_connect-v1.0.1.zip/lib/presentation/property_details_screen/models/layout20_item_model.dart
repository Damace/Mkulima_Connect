import 'package:get/get.dart';class Layout20ItemModel {Rx<String>? id = Rx("");

 }
