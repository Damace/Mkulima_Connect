import 'package:get/get.dart';class Layout21ItemModel {Rx<String> hospitalCounterTxt = Rx("2 Hospital");

Rx<String>? id = Rx("");

 }
