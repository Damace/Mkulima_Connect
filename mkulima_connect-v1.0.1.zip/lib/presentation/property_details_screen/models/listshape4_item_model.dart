import 'package:get/get.dart';class Listshape4ItemModel {Rx<String> nameTxt = Rx("Kurt Mullins");

Rx<String> descriptionTxt = Rx("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ");

Rx<String> durationTxt = Rx("8 Days ago");

Rx<String>? id = Rx("");

 }
