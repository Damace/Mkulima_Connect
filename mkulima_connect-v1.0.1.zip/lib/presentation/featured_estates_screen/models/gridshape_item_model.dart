import 'package:get/get.dart';class GridshapeItemModel {Rx<String> priceTxt = Rx(" 290");

Rx<String> frequencyTxt = Rx("/month");

Rx<String> nameTxt = Rx("Sky Dandelions");

Rx<String> countryTxt = Rx("Jakarta, Indonesia");

Rx<String>? id = Rx("");

 }
