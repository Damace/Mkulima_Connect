import 'package:get/get.dart';import 'gridshape_item_model.dart';class FeaturedEstatesModel {Rx<List<GridshapeItemModel>> gridshapeItemList = Rx(List.generate(4,(index) => GridshapeItemModel()));

 }
