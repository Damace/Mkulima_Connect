import 'package:get/get.dart';import 'layout_item_model.dart';class ReviewFillModel {Rx<List<LayoutItemModel>> layoutItemList = Rx(List.generate(3,(index) => LayoutItemModel()));

 }
