import 'package:get/get.dart';class LayoutItemModel {Rx<String> priceTxt = Rx(" 54,200");

Rx<String>? id = Rx("");

 }
