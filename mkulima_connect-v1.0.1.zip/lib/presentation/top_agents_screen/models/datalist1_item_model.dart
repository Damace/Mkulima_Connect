import 'package:get/get.dart';class Datalist1ItemModel {Rx<String> nameTxt = Rx("Amanda");

Rx<String> ratingTxt = Rx("5.0");

Rx<String>? id = Rx("");

 }
