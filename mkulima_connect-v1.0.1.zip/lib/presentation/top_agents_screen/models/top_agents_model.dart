import 'package:get/get.dart';import 'datalist1_item_model.dart';class TopAgentsModel {Rx<List<Datalist1ItemModel>> datalist1ItemList = Rx(List.generate(6,(index) => Datalist1ItemModel()));

 }
