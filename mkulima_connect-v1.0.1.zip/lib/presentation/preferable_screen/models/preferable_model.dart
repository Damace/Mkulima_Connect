import 'package:get/get.dart';import 'preferable_item_model.dart';class PreferableModel {Rx<List<PreferableItemModel>> preferableItemList = Rx(List.generate(6,(index) => PreferableItemModel()));

 }
