import 'package:get/get.dart';class PreferableItemModel {Rx<String> typeTxt = Rx("House");

Rx<String>? id = Rx("");

 }
