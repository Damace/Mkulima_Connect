import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/summary_change_payment_bottomsheet/models/summary_change_payment_model.dart';class SummaryChangePaymentController extends GetxController {Rx<SummaryChangePaymentModel> summaryChangePaymentModelObj = SummaryChangePaymentModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
