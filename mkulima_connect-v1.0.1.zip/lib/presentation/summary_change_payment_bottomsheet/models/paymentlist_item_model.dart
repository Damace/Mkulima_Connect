import 'package:get/get.dart';class PaymentlistItemModel {Rx<String> accountnumberTxt = Rx("•••••••• 1542");

Rx<String> priceTxt = Rx(" 54,200");

Rx<String>? id = Rx("");

 }
