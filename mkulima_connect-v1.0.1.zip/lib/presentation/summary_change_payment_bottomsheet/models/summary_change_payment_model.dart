import 'package:get/get.dart';import 'paymentlist_item_model.dart';class SummaryChangePaymentModel {Rx<List<PaymentlistItemModel>> paymentlistItemList = Rx(List.generate(3,(index) => PaymentlistItemModel()));

 }
