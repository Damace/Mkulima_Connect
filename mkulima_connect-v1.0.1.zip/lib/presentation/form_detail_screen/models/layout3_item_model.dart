import 'package:get/get.dart';class Layout3ItemModel {Rx<String> buttonCategoryTwoTxt = Rx("House");

Rx<bool> isSelected = Rx(false);

 }
