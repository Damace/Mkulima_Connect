import 'package:get/get.dart';class Layout1ItemModel {Rx<String> buttonCategoryTxt = Rx("Rent");

Rx<bool> isSelected = Rx(false);

 }
