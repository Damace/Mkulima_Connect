import 'package:get/get.dart';class Gridshape1ItemModel {Rx<String> priceTxt = Rx(" 220");

Rx<String> nameTxt = Rx("The Supreme House");

Rx<String> ratingTxt = Rx("4.2");

Rx<String>? id = Rx("");

 }
