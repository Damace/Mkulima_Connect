import 'package:get/get.dart';class DatalistItemModel {Rx<String> nameTxt = Rx("The Laurels Villa");

Rx<String> languageTxt = Rx("4.9 ");

Rx<String> countryTxt = Rx("Bali, Indonesia");

Rx<String> priceTxt = Rx(" 320");

Rx<String> ratetypeTxt = Rx("/night");

Rx<String>? id = Rx("");

 }
