import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/add_location_screen/models/add_location_model.dart';class AddLocationController extends GetxController {Rx<AddLocationModel> addLocationModelObj = AddLocationModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
