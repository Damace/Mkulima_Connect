class AddLocationModel { }
