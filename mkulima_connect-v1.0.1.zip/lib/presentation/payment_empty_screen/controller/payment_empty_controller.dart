import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/payment_empty_screen/models/payment_empty_model.dart';class PaymentEmptyController extends GetxController {Rx<PaymentEmptyModel> paymentEmptyModelObj = PaymentEmptyModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
