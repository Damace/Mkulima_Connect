class PaymentEmptyModel { }
