class ProductTourOneModel { }
