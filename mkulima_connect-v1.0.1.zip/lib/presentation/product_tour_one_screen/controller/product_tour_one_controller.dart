import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/product_tour_one_screen/models/product_tour_one_model.dart';class ProductTourOneController extends GetxController {Rx<ProductTourOneModel> productTourOneModelObj = ProductTourOneModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
