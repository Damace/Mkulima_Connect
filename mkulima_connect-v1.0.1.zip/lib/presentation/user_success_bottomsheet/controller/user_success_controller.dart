import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/user_success_bottomsheet/models/user_success_model.dart';class UserSuccessController extends GetxController {Rx<UserSuccessModel> userSuccessModelObj = UserSuccessModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
