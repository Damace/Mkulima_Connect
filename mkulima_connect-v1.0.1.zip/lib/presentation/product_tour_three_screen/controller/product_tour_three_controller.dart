import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/product_tour_three_screen/models/product_tour_three_model.dart';class ProductTourThreeController extends GetxController {Rx<ProductTourThreeModel> productTourThreeModelObj = ProductTourThreeModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
