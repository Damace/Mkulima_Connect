class ProductTourThreeModel { }
