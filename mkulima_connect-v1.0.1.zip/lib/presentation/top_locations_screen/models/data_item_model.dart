import 'package:get/get.dart';class DataItemModel {Rx<String> destinationnameTxt = Rx("Bali");

Rx<String>? id = Rx("");

 }
