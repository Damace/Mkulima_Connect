import 'package:get/get.dart';import 'data_item_model.dart';class TopLocationsModel {Rx<List<DataItemModel>> dataItemList = Rx(List.generate(6,(index) => DataItemModel()));

 }
