import 'package:get/get.dart';class VerticalItemModel {Rx<String> priceTxt = Rx(" 320");

Rx<String> unitTxt = Rx("/night");

Rx<String> nameTxt = Rx("The Laurels Villa");

Rx<String> countryTxt = Rx("Bali, Indonesia");

Rx<String>? id = Rx("");

 }
