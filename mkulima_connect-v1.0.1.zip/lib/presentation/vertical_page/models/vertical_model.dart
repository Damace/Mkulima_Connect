import 'package:get/get.dart';import 'vertical_item_model.dart';class VerticalModel {Rx<List<VerticalItemModel>> verticalItemList = Rx(List.generate(3,(index) => VerticalItemModel()));

 }
