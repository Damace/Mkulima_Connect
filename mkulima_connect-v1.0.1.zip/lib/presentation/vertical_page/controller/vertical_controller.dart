import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/vertical_page/models/vertical_model.dart';class VerticalController extends GetxController {VerticalController(this.verticalModelObj);

Rx<VerticalModel> verticalModelObj;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
