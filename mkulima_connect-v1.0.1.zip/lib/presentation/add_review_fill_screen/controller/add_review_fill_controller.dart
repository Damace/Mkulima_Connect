import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/add_review_fill_screen/models/add_review_fill_model.dart';class AddReviewFillController extends GetxController {Rx<AddReviewFillModel> addReviewFillModelObj = AddReviewFillModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
