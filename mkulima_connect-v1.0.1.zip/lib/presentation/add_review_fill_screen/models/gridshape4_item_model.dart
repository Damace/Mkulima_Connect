import 'package:get/get.dart';class Gridshape4ItemModel {Rx<String>? id = Rx("");

 }
