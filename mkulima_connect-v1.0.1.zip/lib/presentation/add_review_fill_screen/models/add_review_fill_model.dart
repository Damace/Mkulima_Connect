import 'package:get/get.dart';import 'gridshape4_item_model.dart';class AddReviewFillModel {Rx<List<Gridshape4ItemModel>> gridshape4ItemList = Rx(List.generate(3,(index) => Gridshape4ItemModel()));

 }
