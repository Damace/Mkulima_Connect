class FavouriteEmptyModel { }
