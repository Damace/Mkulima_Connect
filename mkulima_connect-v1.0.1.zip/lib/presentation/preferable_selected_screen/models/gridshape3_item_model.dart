import 'package:get/get.dart';class Gridshape3ItemModel {Rx<String> typeTxt = Rx("Apartment");

Rx<String>? id = Rx("");

 }
