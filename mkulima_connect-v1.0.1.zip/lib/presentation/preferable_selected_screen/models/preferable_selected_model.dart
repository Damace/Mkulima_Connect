import 'package:get/get.dart';import 'gridshape3_item_model.dart';class PreferableSelectedModel {Rx<List<Gridshape3ItemModel>> gridshape3ItemList = Rx(List.generate(6,(index) => Gridshape3ItemModel()));

 }
