import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/preferable_selected_screen/models/preferable_selected_model.dart';class PreferableSelectedController extends GetxController {Rx<PreferableSelectedModel> preferableSelectedModelObj = PreferableSelectedModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
