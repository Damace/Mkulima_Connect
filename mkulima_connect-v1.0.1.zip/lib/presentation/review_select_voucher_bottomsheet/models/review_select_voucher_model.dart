import 'package:get/get.dart';import 'listticket_item_model.dart';class ReviewSelectVoucherModel {Rx<List<ListticketItemModel>> listticketItemList = Rx(List.generate(2,(index) => ListticketItemModel()));

 }
