import 'package:get/get.dart';class ListticketItemModel {Rx<String> codeTxt = Rx("HLWN40");

Rx<String>? id = Rx("");

 }
