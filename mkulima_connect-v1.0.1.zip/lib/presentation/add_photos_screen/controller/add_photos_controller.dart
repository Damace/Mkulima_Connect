import 'package:mkulima_connect/core/app_export.dart';import 'package:mkulima_connect/presentation/add_photos_screen/models/add_photos_model.dart';class AddPhotosController extends GetxController {Rx<AddPhotosModel> addPhotosModelObj = AddPhotosModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
