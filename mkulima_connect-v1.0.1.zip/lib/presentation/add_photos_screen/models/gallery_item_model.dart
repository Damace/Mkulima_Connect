import 'package:get/get.dart';class GalleryItemModel {Rx<String>? id = Rx("");

 }
