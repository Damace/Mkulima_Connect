import 'package:get/get.dart';import 'gallery_item_model.dart';class AddPhotosModel {Rx<List<GalleryItemModel>> galleryItemList = Rx(List.generate(4,(index) => GalleryItemModel()));

 }
