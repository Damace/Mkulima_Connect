import 'package:get/get.dart';class Listshape3ItemModel {Rx<String> nameTxt = Rx("Bridgeland Modern House");

Rx<String> ratingTxt = Rx("4.9");

Rx<String> priceTxt = Rx(" 260");

Rx<String>? id = Rx("");

 }
