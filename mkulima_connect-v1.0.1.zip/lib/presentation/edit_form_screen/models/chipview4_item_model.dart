import 'package:get/get.dart';class Chipview4ItemModel {Rx<String> buttonCategoryThirteenTxt = Rx("Parking Lot");

Rx<bool> isSelected = Rx(false);

 }
