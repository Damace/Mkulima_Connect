import 'package:get/get.dart';class Layout12ItemModel {Rx<String> buttonCategoryTxt = Rx("Rent");

Rx<bool> isSelected = Rx(false);

 }
