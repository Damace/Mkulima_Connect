import 'package:get/get.dart';class Layout16ItemModel {Rx<String> buttonCategorySevenTxt = Rx("Monthly");

Rx<bool> isSelected = Rx(false);

 }
