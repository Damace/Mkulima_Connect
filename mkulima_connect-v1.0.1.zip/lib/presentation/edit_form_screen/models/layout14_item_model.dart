import 'package:get/get.dart';class Layout14ItemModel {Rx<String> buttonCategoryTwoTxt = Rx("House");

Rx<bool> isSelected = Rx(false);

 }
