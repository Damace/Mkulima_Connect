import 'package:get/get.dart';class Gridshape5ItemModel {Rx<String>? id = Rx("");

 }
