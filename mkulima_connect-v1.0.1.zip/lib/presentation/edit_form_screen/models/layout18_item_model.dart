import 'package:get/get.dart';class Layout18ItemModel {Rx<String> buttonCategoryNineTxt = Rx("< 4");

Rx<bool> isSelected = Rx(false);

 }
