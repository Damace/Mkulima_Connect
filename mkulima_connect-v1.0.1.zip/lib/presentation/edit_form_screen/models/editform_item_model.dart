import 'package:get/get.dart';class EditformItemModel {Rx<String> typeTxt = Rx("Bedroom");

Rx<String>? id = Rx("");

 }
