import 'package:get/get.dart';class PaymentMastercardModel {Rx<DateTime>? selectedDateTxt = Rx(DateTime.now());

Rx<String> dateTxt = Rx("");

 }
