class PromotionModel { }
